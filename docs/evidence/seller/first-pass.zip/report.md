# Executed seller workflow evaluation

| Approach | Successful samples | Critical failures | Median / p95 inference | Tokens |
|---|---:|---:|---:|---:|
| grounded_workflow | 104/120 | 9 | 3.27s / 7.52s | 114,325 |
| simple_llm | 82/120 | 15 | 4.57s / 6.43s | 104,442 |
| template | 60/120 | 20 | 0.00s / 0.00s | 0 |

The suite has 60 distinct synthetic cases. Repeated runs are not independent customer samples. Cases cover discovery, ambiguity, support, suppression, contradictory requirements and hostile note instructions.

The rubric tests action choice, exact quotation and required information. It does not prove general semantic support or seller usefulness. Human usefulness review is pending. No conversion or revenue uplift is claimed.

All case families are known to the implementer; held-out variants measure within-family generalisation. This is not an independently curated or blinded external benchmark.

[Evaluation and acceptance results](evaluation.json) · [Cases and fixed rubric](suite.json)
